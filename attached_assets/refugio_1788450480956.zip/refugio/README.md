# Refúgio — Landing + Lista de espera

Landing page da comunidade anônima **Refúgio** com captura real de e-mails e um
painel de admin. **Sem dependências** — roda só com Node.js.

## Rodar localmente

```bash
node server.js
# ou: npm start
```

Depois abra: <http://localhost:3000>
Painel: <http://localhost:3000/admin>

Defina uma senha para o painel (usuário do painel é sempre `admin`):

```bash
ADMIN_PASSWORD=suaSenhaForte node server.js
```

## O que cada coisa faz

- `public/index.html` — a landing (design + copy). É só isto que o visitante vê.
- `server.js` — servidor Node puro: serve a página, recebe os cadastros e mostra o painel.
- `data/signups.json` — onde os cadastros ficam salvos (criado sozinho).

Os formulários enviam **e-mail** + **intenção** (`desabafar`, `acolher`, `ambos`).
No painel você vê o total, a **% de quem topa acolher** (o número que importa no
teste) e pode **baixar tudo em CSV**.

## Publicar no Replit

1. Crie um Repl (ou importe este repositório do GitHub).
2. Em **Secrets**, adicione `ADMIN_PASSWORD` com uma senha sua.
3. Clique em **Run**. O comando é `node server.js` (já está no `package.json`).
4. Use **Deploy** para ter um link público fixo.

> Dica: para o link do teste, use `?ref=` para saber a origem —
> ex.: `.../?ref=instagram`, `.../?ref=bio`. A origem aparece no painel.

## Subir para o GitHub

```bash
git add .
git commit -m "Landing do Refúgio com captura de e-mail e painel admin"
git push
```

## Observações

- **Privacidade:** só guardamos e-mail, intenção, origem e data. Nada é público.
- **Persistência:** os cadastros ficam em `data/signups.json`. Faça backup do
  arquivo (ou baixe o CSV) de tempos em tempos. Para um deploy que escala,
  o ideal depois é migrar para um banco de verdade (posso te ajudar nisso).
- **Segurança:** nunca deixe a senha no código — use o Secret `ADMIN_PASSWORD`.
